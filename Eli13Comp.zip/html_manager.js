/**************************************************************/
// html_manager.js

// Written by Eli Church

// Contains functions called in html by onload
/**************************************************************/
var html_adminStatus = "n";
var leaderboardReverse = false;
/**************************************************************/
// html_load()
// Called by everything onload
// calls fbR_initialise() and gets info from session storage
// also sets "logged in as " text to have username
// Input:  n/a
// Output: n/a
/**************************************************************/
function html_load() {
  console.log("c%html_load", "color: green;");
  
  fbR_initialise();
  
  userDetails.uid = sessionStorage.getItem("uid");
  userDetails.email = sessionStorage.getItem("email");
  userDetails.displayName = sessionStorage.getItem("displayName");
  userDetails.photoURL = sessionStorage.getItem("photoURL");
  userDetails.gameName = sessionStorage.getItem("gameName");
  userDetails.age = sessionStorage.getItem("age");
  userDetails.gender = sessionStorage.getItem("gender");
  userDetails.GTNwins = sessionStorage.getItem("GTNwins");
  html_adminStatus = sessionStorage.getItem("adminStatus");

  console.log("username: " + userDetails.gameName);
  if (userDetails.gameName == null) {
      window.location = "index.html";
  }
  document.getElementById("loggedInAs").innerHTML = 
  "Logged in as: " + userDetails.gameName;
  

/** setCustomUserClaims({ uid: userDetails.uid, username: userDetails.gameName })
  .then(result => {
    console.log(result.data.message);
  })
  .catch(error => {
    console.error('Error setting custom claims:', error);
  });**/
}
/**************************************************************/
// html_adminButton()
// Called onload by game_select
// Checks if user is admin to display button or not 
// Input:  n/a
// Output: n/a
/**************************************************************/
function html_adminButton() {
  console.log("html_adminButton: " + html_adminStatus);
  document.getElementById('admin-btn').style.visibility= 'hidden';
  if (html_adminStatus == "y") {
      console.log("show admin");
      document.getElementById('admin-btn').style.visibility= 'visible';
  }
}
/**************************************************************/
// html_buildTableLobby(_tableBodyID, _array)
// Called by html_start()
// Build html table rows from an array of objects FOR THE LOBBY
// Input:  html id of table body, array of objects
// Output: n/a
/**************************************************************/
function html_buildTableLobby(_tableBodyID, _array){
    console.log("%chtml_buildTable: ", 'color: brown');
    console.table(_array);
    if (leaderboardReverse == true) {
        console.log('reverse array');
        _array.reverse();
    }
    //console.log(${_array[i].uid})
    //console.log(${_array[i].state})
    //Get all the info on the table
    var table = document.getElementById(_tableBodyID);
    // Reverse loop thu array of objects; build row & add it to table
    // MAKE SURE THE OBJECT FEILD NAMES ARE CORRECT FOR YOU        <============
    if (_array == '') {
        console.log("no lobbies");
        var row =   `<tr>       
                        <td>No lobbies open...</td>
                        <td></td>
                    </tr>`;
        table.innerHTML += row;
    }
    else {
        for (i = _array.length-1; i >= 0; i--) {
        // Back ticks define a temperate literal
        var row =   `<tr>       
                        <td>${_array[i].uid}</td>
                        <td class="w3-center">
                        <button onclick="fbR_join
                        ('${_array[i].uid}')"
                        class="w3-button w3-black w3-round">Join</button>
                        </td>
                    </tr>`;
        table.innerHTML += row;
    }
  }
}//, 'closed', ${_array[i].state}
/**************************************************************/
// html_lobbyTable(_path)
// Called onload on lobby page
// Starts the sorted read of lobby records
//  which then builds the lobby table
// Input:  Path of record to build table from
// Output: Read all sorted
/**************************************************************/
function html_lobbyTable(_path) {
  console.log("$chtml_gtnLeaderboard: ", 'color: brown');
  console.log(document.getElementById("leaderboardSort"));
  // reset any previous data
  document.getElementById("lobby_table").innerHTML = '';
  html_leaderArray = [];
  leaderboardReverse = false;
  
  // Set GTN sort key & number of leaderboard entries to display  <============
  var sortKey = 'childData';                                   //<============
  //var num = Number(document.getElementById("leaderboardNum").value); //<============
  var num = 99;
  var path = 'lobby/GTN';
  //var path = document.getElementById("leaderboardSort").value;
  //console.log(num)
  Number(num);
  console.log(_path);
  if (_path == 'lobby') {
    console.log('reverse array');
    leaderboardReverse = true; 
  }
  fb_readAllSorted(_path, html_leaderArray, sortKey, num, 
                   fbR_procReadSorted_lobby);
}

/**************************************************************/
// lobby_load()
// Called by onload
// Gets the wins of the user when they load into the lobby page
// 
// Input:  n/a
// Output: n/a
/**************************************************************/
function lobby_load() {
      fb_readRec('scores/GTN', userDetails.gameName, fbR_procWins);
      console.log('LOBBY LOAD BIH');
}
/**************************************************************/
// gtn_load()
// Called by onload
// Starts the GTN game
// Writes the records and collects the information
// Input:  n/a
// Output: n/a
/**************************************************************/
function gtn_load() {
    console.log("c%gtn_load", "color: green;");

    var otherPlayer;
    var lobbyID = sessionStorage.getItem("lobbyID");
    var playerStatus = sessionStorage.getItem("playerStatus");
    var gameName = sessionStorage.getItem("gameName");
    var playerInfo = {
        gameName: userDetails.gameName,
        connected: true,
        currentGuess: '...',
        wins: userDetails.GTNwins,};
        
    console.log("status: " + playerStatus);
    
    document.getElementById("lobbyID").innerHTML = 
    lobbyID + "'s Lobby";
    
    if (playerStatus == 'p1') {
        console.log("player 1");
        console.log(userDetails.gameName);
        //fb_writeRec
        //('games/GTN/' + lobbyID, 'p1', playerInfo, fbR_procWrite)
        otherPlayer = 'p2';
        sessionStorage.setItem("otherPlayer", otherPlayer);
        document.getElementById("turn").innerHTML = 'Your turn!';
        fb_readRec('games/GTN/' + lobbyID, 'secretNumber', fbR_procNumber);
    }
    else if (playerStatus == 'p2') {
        console.log("player 2");
        otherPlayer = 'p1';
        sessionStorage.setItem("otherPlayer", otherPlayer);
        //fb_writeRec
        //('games/GTN/' + lobbyID, 'p2', playerInfo, fbR_procWrite)
        document.getElementById("turn").innerHTML = 'Their turn...';
    }
    fb_readOn('games/GTN/' + lobbyID, 'gameStatus', fbR_procReadWin);
    fb_readOn('games/GTN/' + lobbyID, 'turn', fbR_procReadTurn);
    fb_readOn('games/GTN/' + lobbyID + '/' + otherPlayer, 
    'currentGuess', fbR_procReadGuess);
    
    getInfo(otherPlayer, lobbyID);
}
/**************************************************************/
// getInfo(_otherPlayer, _lobbyID)
// Collects the other player's info
// 
// Input: Other players game name, the lobby ID
// Output: Reads 
/**************************************************************/
function getInfo(otherPlayer, lobbyID) {
    console.log("getInfo, " + otherPlayer);
    fb_readRec('games/GTN/' + lobbyID + '/' + otherPlayer, 'gameName', fbR_getGameName);
    fb_readRec('scores/GTN/' + otherPlayer, 'wins', fbR_getOpponentWins);
}
/**************************************************************/
// html_Leaderboard()
// Called by html LEADERBOARD button
// Starts the sorted dread all of scores 
//  which then builds leaderboard
// Input:  n/a
// Output: read all sorted
/**************************************************************/
function html_Leaderboard() {
  console.log("$chtml_Leaderboard: ", 'color: brown');
  console.log(document.getElementById("leaderboardSort"));
  // reset any previous data
  document.getElementById("leader_table").innerHTML = '';
  html_leaderArray = [];
  leaderboardReverse = false;
  
  // Set KA sort key & number of leaderboard entries to display  <============
  var sortKey = 'childData' ;                                      //<============
  var num = Number(document.getElementById("leaderboardNum").value);      //<============
  var path = document.getElementById("leaderboardPath").value;
  console.log(num);
  Number(num);
  console.log(3);
  console.log(path);
  var order = document.getElementById("leaderboardSort").value;
  if (order == 'low') {
    console.log('reverse array');
    leaderboardReverse = true; 
  }
  else {
     leaderboardReverse = false;
  }
  fb_readAllSorted(path, html_leaderArray, sortKey, num, 
                   fbR_procReadSorted_Leader);
}
/**************************************************************/
// html_buildTableLeader(_tableBodyID, _array)
// Called by html_start()
// Build html table rows from an array of objects FOR LEADERBOARD
// Input:  html id of table body, array of objects
// Output: n/a
/**************************************************************/
function html_buildTableLeader(_tableBodyID, _array){
  console.log("%chtml_buildTable: ", 'color: brown');
  console.table(_array);
  if (leaderboardReverse == true) {
    console.log('reverse array');
    _array.reverse();
  }

  // Get all the info on the table
  var table = document.getElementById(_tableBodyID);
  // Reverse loop thu array of objects; build row & add it to table
  // MAKE SURE THE OBJECT FEILD NAMES ARE CORRECT FOR YOU        <============
  for (i = _array.length-1; i >= 0; i--) {
    // Back ticks define a temperate literal
    var row = `<tr>       
                <td>${_array[i].uid}</td>
                <td class="w3-center">${_array[i].state}</td>
              </tr>`;
    table.innerHTML += row;
  }
}
/**************************************************************/
//    END OF MODULE
/**************************************************************/