/**************************************************************/
// fbR_manager.js

// Written by Eli Church

// Contains all non-generic functions for the database and game
/**************************************************************/
MODULENAME = "fbR_manager.js";
console.log('%c' + MODULENAME + ': ', 'color: blue;');
/**************************************************************/
// fbR_initialise()
// Called by html load
// Initialize firebase
// Input:  n/a
// Return: n/a
/**************************************************************/
var userDetails = {
  uid:      '',
  email:    '',
  photoURL: '',
  gameName: '',
  gender:   '',
  age:      '',
};

function fbR_initialise() {
  console.log('%cfbR_initialise: ', 'color: brown;');
  
   /** import firebase from 'firebase/app';
    import 'firebase/functions';**/
    
  // PLACE YOUR CONFIG FROM THE FIREBASE CONSOLE BELOW <========
  const FIREBASECONFIG = {
    apiKey: "AIzaSyDJGK1A7d-Nt3ISxyfxm_WUA5H_SnTOLws",
    authDomain: "comp-2024-eli-church.firebaseapp.com",
    databaseURL: "https://comp-2024-eli-church-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "comp-2024-eli-church",
    storageBucket: "comp-2024-eli-church.appspot.com",
    messagingSenderId: "232347824498",
    appId: "1:232347824498:web:1081507889dfbbbadeadeb",
    measurementId: "G-C677NZVJ8K"
  };

 /** var functions = firebase.functions();

  var setCustomUserClaims = firebase.functions().httpsCallable('setCustomUserClaims');
**/
  // Check if firebase already initialised
  if (!firebase.apps.length) {
    firebase.initializeApp(FIREBASECONFIG);
    database = firebase.database();
  }
}
/**************************************************************/
// fbR_procLogin()
// Called by login button
// Initialize firebase
/**************************************************************/
function fbR_procLogin (_loginStatus, _user, _save) {
  console.log("fbR_procLogin");
  _save.uid      = _user.uid;
  _save.email    = _user.email;
  _save.name     = _user.displayName;
  _save.photoURL = _user.photoURL;

  sessionStorage.setItem("uid", _user.uid);
  sessionStorage.setItem("email", _user.email);
  sessionStorage.setItem("displayName", _user.displayName);
  sessionStorage.setItem("photoURL", _user.photoURL);

  fb_readRec('userDetails', _user.uid, fbR_procReadUD, _save);
  //fb_writeRec('userDetails', userDetails.uid, userDetails, fbR_procWriteReg)
}
/**************************************************************/
// fbR_procUserDetails(_readStatus, _dbData, _save, _error)
// Read all DB records for the path
// Called by login button
// Input: Read status, database data, save location, errors
// Return: User's info
/**************************************************************/
function fbR_procUserDetails (_readStatus, _dbData, _save, _error) {
    console.log("fbR_procUserDetails: readStatus= " + _readStatus);
  
    if (snapshot.val() == null) {
      readStatus = "no record";
    }
    else {
      readStatus = "OK";
      console.log("read ok");
      //console.log(snapshot.val());
      let dbData = snapshot.val();
    }
  
    if (_readStatus == "OK") {
      _save.uid      = _dbData.uid;
      _save.name     = _dbData.name;
      _save.email    = _dbData.email;
      _save.photoURL = _dbData.photoURL;
      _save.score    = _dbData.score;
    }
    else if (readStatus == "failed") {
      console.log(_error);
    }
}
/**************************************************************/
// fbR_register()
// Store user's data
// Called by registration page button
// Input: registration form
// Return: n/a
/**************************************************************/
const AGEMAX = 100;
const AGEMIN = 12;
function fbR_register() {
    console.log("fbR_register");
  
    userDetails.age       = document.getElementById("userAge").value;
    userDetails.gender    = document.getElementById("userGender").value;
    userDetails.gameName  = document.getElementById("gameName").value;
    userDetails.wins      = 0;

    if (!isNaN(userDetails.gameName) || 
        userDetails.gameName == "" || 
        userDetails.gameName == " ") {
        console.error("gameName invalid");
        alert("Username invalid. Please try again.");
    }
    else if (isNaN(userDetails.age)) {
        console.error("age invalid");
        alert("Age invalid. Please try again.");
    }
    else if (userDetails.age >= AGEMAX || userDetails.age <= AGEMIN) {
        console.error("age incorrect size");
        alert("Age invalid. Please select and age between 13-99.");
    }
    else if (userDetails.gender == "X") {
        console.error("gender invalid");
        alert("Please select a gender option.");
    }
    else {
        console.log("Input valid");
        sessionStorage.setItem("gameName", userDetails.gameName);
        sessionStorage.setItem("wins", userDetails.wins);
        console.log(userDetails.age +" "+ 
                    userDetails.gender +" "+ userDetails.gameName);
        //fb_writeRec('admin', userDetails.uid, 'n', fbR_procWriteReg);
        fb_writeRec('userDetails', userDetails.uid, userDetails, fbR_procWriteReg);
    }
}    
/**************************************************************/
// fbR_procWriteReg ()
// Redirect user after registration
// Called by registration page
// Input: User's registration info
// Return: write status
/**************************************************************/
function fbR_procWriteReg(_error) {
  console.log("fbR_procWriteReg:");
  if (_error) {
    writeStatus = "failed";
    console.error(_error);
    alert("write error\nplease see console log");
  }
  else {
    writeStatus = "OK";
    console.log("fbR_procWriteReg: write success");
    window.location = "game_select.html";
  }
}
/**************************************************************/
// fbR_procWrite ()
// GENERIC PROCWRITE
// Called by many
// Input: _error 
// Return: n/a
/**************************************************************/
function fbR_procWrite(_error) {
  console.log("fbR_procWrite:");
  if (_error) {
    writeStatus = "failed";
    console.error(_error);
    alert("write error\nplease see console log");
  }
  else {
    writeStatus = "OK";
    console.log("fbR_procWrite: write success");
  }
}
/**************************************************************/
// fbR_procReadUD (_readStatus, _snapshot, _save, _error)
// Called by fbR_procLogin
// Determine if user is registered.
// Input:  snapshot/error
// Return:  error, snapshot null or not null
/**************************************************************/
function fbR_procReadUD(_readStatus, _snapshot, _save, _error) {
  console.log("fbR_procReadUD: readStatus= " + _readStatus);
  var dbData = _snapshot.val();
  if (_error) {
    readStatus = "failed";
    console.error("%cread error" + _error, 'color: red;');
    alert ("Read Error! Please see console log.");
  }
  else {
    if (dbData == null) {
      //not registered
      console.log("user not registered, going to register page");
      window.location = "register.html";
    }
    else {
      //user registered
      readStatus = "OK";
      console.log("read success, user registered");
      sessionStorage.setItem("gameName", dbData.gameName);
      console.log(dbData.gameName);
      fb_readRec('admin', userDetails.uid, fbR_procReadAdmin, _save);
      window.location = "game_select.html";
      //check if user admin, save firebase 
      // stuff game name to session storage, go to games
    }
  }
}
/**************************************************************/
// fbR_procReadAllUD (_readStatus, _snapshot, _save, _error)
// Called by proclogin
// Input:  snapshot/error
// Return:  error, snapshot null or not null
/**************************************************************/
function fbR_procReadAllUD() {
  console.log("fbR_procReadAllUD: readStatus= " + _readStatus);
  if (error) {
    readStatus = "failed";
    console.log("read error");
  }
  else {
    readStatus = "OK";
    console.log("read success");
  }
}
/**************************************************************/
// fbR_procReadAdmin(_readStatus, _snapshot, _save, _error)
// called onload 
// checks if admin user, sets admin sessionStorage & go to gameSelect
// Input:  _readStatus, _snapshot, _save, _error
// Return: y or n
/**************************************************************/
function fbR_procReadAdmin(_readStatus, _snapshot, _save, _error) {
  console.log("fbR_procReadAdmin: readStatus= " + _readStatus);
  var dbData = _snapshot.val();
  if (_error) {
    readStatus = "failed";
    console.error("%cread error" + _error, 'color: red;');
    alert ("Admin read error! Please see console log.");
  }
  else {
    if (dbData == null) {
      //not admin
      console.log("fbR_procReadAdmin: user not admin");
      sessionStorage.setItem("adminStatus", "n");
    }
    else {
      //user is admin
      readStatus = "OK";
      console.log("fbR_procReadAdmin: user admin");
      sessionStorage.setItem("adminStatus", "y");
    }
    //window.location = "game_select.html";
  }
}
/**************************************************************/
// fbR_procReadKA(_readStatus, _snapshot, _save, _error)
// called by ka_load()
// checks if the user has a score
// Input:  _readStatus, _snapshot, _save, _error
// Return: y or n
/**************************************************************/
function fbR_procReadKA(_readStatus, _snapshot, _save, _error) {
  console.log("fbR_procReadKA");
  var dbData = _snapshot.val();
  if (_error) {
    readStatus = "failed";
    console.error("%cread error" + _error, 'color: red;');
    alert ("Read Error! Please see console log.");
  }
  else {
    if (dbData == null) {
      //no score
      console.log("fbR_procReadKA: no previous user score");
      userScoresKA.ka = "no score";
    }
    else {
      //user has score
      readStatus = "OK";
      console.log("fbR_procReadKA: read success, user has score");
      userScoresKA.ka = dbData;
      console.log(dbData);
      sessionStorage.setItem("ka_score", dbData);
    }
  }
}
/**************************************************************/
// fbR_procReadFL(_readStatus, _snapshot, _save, _error)
// called by fl_load()
// checks if the user has a score
// Input:  _readStatus, _snapshot, _save, _error
// Return: y or n
/**************************************************************/
function fbR_procReadFL(_readStatus, _snapshot, _save, _error) {
  console.log("fbR_procReadFL");
  var dbData = _snapshot.val();
  if (_error) {
    readStatus = "failed";
    console.error("%cread error" + _error, 'color: red;');
    alert ("Read Error! Please see console log.");
  }
  else {
    if (dbData == null) {
      //no score
      console.log("fbR_procReadFL: no previous user score");
      userScoresFL.fl = "no score";
    }
    else {
      //user has score
      readStatus = "OK";
      console.log("fbR_procReadFL: read success, user has score");
      userScoresFL.fl = dbData;
      console.log(dbData);
      sessionStorage.setItem("fl_score", dbData);
    }
  }
}
/**************************************************************/
// fbR_procReadSorted_lobby(_path, snapshot, _save)
// Callback from firebase read (fb_readAllSorted) 
// Process data from sorted read of all GTN records
// Input:  read status, database data & where to save it &
//         error message if any 
// Output: n/a  
/**************************************************************/
function fbR_procReadSorted_lobby(_readStatus, _snapshot, _save, _error) {
  console.log("%cfbR_procReadSorted_gtn: readStatus = " + _readStatus,
             'color: brown');

  if (_readStatus != 'error') {
    var recCount = 0;
    if (_snapshot.val() != null) {	// if data returned	
      _snapshot.forEach(function(childSnapshot) {
        recCount++;
        // if you need access to the key
        var childKey  = childSnapshot.key;
        var childData = childSnapshot.val();
        _save.push({
          uid:       childKey,
          state:     childData
        });
      });
    }
    console.log("%cfbR_procReadSorted_gtn: " + 
                recCount + ' records', 'color: brown');
    console.table(_save);
    // Build the html table 
    html_buildTableLobby("lobby_table", _save);
  }
  else {
    console.error(_error);
    alert('firebase read error.\nPlease see console log for details');
  }
}
/**************************************************************/
// fbR_procReadSorted_Leader(_readStatus, _snapshot, _save, _error)
// Callback from firebase read (fb_readAllSorted) 
// Process data from sorted read of all GTN records
// Input:  read status, database data & where to save it &
//         error message if any
// Output: n/a 
/**************************************************************/
function fbR_procReadSorted_Leader(_readStatus, _snapshot, _save, _error) {
  console.log("%cfbR_procReadSorted_gtn: readStatus = " + _readStatus,
             'color: brown');

  if (_readStatus != 'error') {
    var recCount = 0;
    if (_snapshot.val() != null) {	// if data returned	
      _snapshot.forEach(function(childSnapshot) {
        recCount++;
        // if you need access to the key
        var childKey  = childSnapshot.key;
        var childData = childSnapshot.val();
        _save.push({
          uid:       childKey,
          state:     childData
        });
      });
    }
    console.log("%cfbR_procReadSorted_gtn: " + 
                recCount + ' records', 'color: brown');
    console.table(_save);
    // Build the html table 
    html_buildTableLeader("leader_table", _save);
  }
  else {
    console.error(_error);
    alert('firebase read error.\nPlease see console log for details');
  }
}
/**************************************************************/
// fbR_procLobby ()
// procfunc for lobby readon
// Called by creating lobby
// Input: readstatus, snapshot, save, error
// Return: lobby joined
/**************************************************************/
function fbR_procLobby(_readStatus, _snapshot, _save, _error) {
    console.log("fbR_procLobby: readStatus= " + _readStatus);
    var dbData = _snapshot.val();
    var lobbyID = sessionStorage.getItem("lobbyID");
    var playerStatus = sessionStorage.getItem("playerStatus");
    var gameName = sessionStorage.getItem("gameName");
    var playerInfo = {
        gameName: userDetails.gameName,
        connected: true,
        currentGuess: '...',
        wins: userDetails.GTNwins,};
        
    if (_error) {
        readStatus = "failed";
        console.log("read error");
  }
  else {
    readStatus = "OK";
    console.log("read success");
    console.log(dbData);
    if (dbData == false) {
        console.log("GTN: Lobby joined");
        sessionStorage.setItem("p1", userDetails.gameName);
        fb_readOnCancel('lobby/GTN/' + userDetails.gameName);
        //fb_writeRec
        //('games/GTN', userDetails.gameName, 'p1', fbR_procWrite)
        //ref.onDisconnect().cancel();
        fb_remove('lobby/GTN', userDetails.gameName);
        fb_readOnCancel('lobby/GTN', userDetails.gameName);
        fb_writeRec
        ('games/GTN/' + lobbyID, 'p1', playerInfo, fbR_procWrite);
        
        window.location = "/games/gtn.html";
    }
    else if (dbData == true) {
        console.log("GTN: Lobby open");
    }
    else {
        console.error("readOn error");
    }
  }
}
/**************************************************************/
// fbR_join ()
// join a lobby
// Called when you join a lobby
// Input: path of the lobby 
// Return: path key data proc func
/**************************************************************/
function fbR_join(_path) {
    console.log("fbR_joinGTN: " + _path);
    sessionStorage.setItem("lobbyID", _path);
    sessionStorage.setItem("p2", _path);
    sessionStorage.setItem("playerStatus", 'p2');
    console.log(userDetails.gameName);
    fb_writeRec('lobby/GTN/' + _path, 'status', false, fbR_procWrite);
    
    var gameArray = {
        secretNumber: 'not generated',
        turn: 1,
        gameStatus: 'inprog',};
    var lobbyID = sessionStorage.getItem("lobbyID");
    var playerStatus = sessionStorage.getItem("playerStatus");
    var gameName = sessionStorage.getItem("gameName");
    var playerInfo = {
        gameName: userDetails.gameName,
        connected: true,
        currentGuess: '...',
        wins: userDetails.GTNwins,};
    
    gameArray.secretNumber = Math.floor(Math.random()*100);
    sessionStorage.setItem("secretNumber", gameArray.secretNumber);
    
    fb_writeRec('games/GTN', _path, gameArray, fbR_procWrite);
    fb_writeRec
    ('games/GTN/' + lobbyID, 'p2', playerInfo, fbR_procWrite);
    
    window.location = '/games/gtn.html';
}
/**************************************************************/
// fbR_create (_path, _key)
// Create a lobby 
// Called when lobby created
// Input: path and key
// Return: write and readon
/**************************************************************/
function fbR_create (_path, _key) {
    var lobbyDetails = {
        gameName: userDetails.gameName,
        status: true,
        procfunc: 'fbR_procWrite',};
    console.log(_key);
    console.log('fbR_create');
    sessionStorage.setItem("lobbyID", _key);
    sessionStorage.setItem("playerStatus", 'p1');
    lobbyTimerVar = 120;
    fbR_p1OnDisconnect(_path, userDetails.gameName);
    fb_writeRec(_path, userDetails.gameName, lobbyDetails, fbR_procWrite);
    fb_readOn(_path + '/' + _key, 'status', fbR_procLobby);
} 
/**************************************************************/
// fbR_lobbyTimer (_path, _key)
// Timer for lobby 
// Called when lobby created
// Input: n/a
// Return: timer 
/**************************************************************/
var lobbyTimerVar = 120;
var lobbyTimeout;
function fbR_lobbyTimer () {
    lobbyTimeout = setInterval(lobbyTimer, 1000);
    function lobbyTimer () {
        console.log("timer: " + lobbyTimerVar);
        lobbyTimerVar--;
        document.getElementById("lobbyTimer").innerHTML = lobbyTimerVar;
        if (lobbyTimerVar == 0) {
            clearInterval(lobbyTimeout);
            document.getElementById('lobbyModal').style.display='none';
            fb_remove('lobby/GTN', userDetails.gameName);
            fb_readOnCancel('lobby/GTN', userDetails.gameName);
        }
    }
} 
/**************************************************************/
// fbR_getGameName (_readStatus, _snapshot, _save)
// Gets opponents username
// called onload for the game
// Input: snapshot
// Return: opponents game name
/**************************************************************/
function fbR_getGameName (_readStatus, _snapshot, _save) {
    console.log("fbR_getGameName: " + opponentName);
    var opponentName = _snapshot.val();
    sessionStorage.setItem("opponentGameName", opponentName);
    document.getElementById("otherBox").innerHTML = opponentName;
}
/**************************************************************/
// fbR_getWins (_readStatus, _snapshot, _save)
// Get the wins of the opponent
// Called onload of the game
// Input: snapshot
// Return: wins of opponent
/**************************************************************/
function fbR_getOpponentWins (_readStatus, _snapshot, _save) {
    console.log("fbR_getOpponentWins");
    let opponentWins = _snapshot.val();
    console.log('Opponent wins = ' + opponentWins);
    sessionStorage.setItem("opponentWins", opponentWins);
    //document.getElementById("otherBox").innerHTML = opponentWins;
}
/**************************************************************/
// fbR_playerGuess (_path, _key)
// Checks guess of player
// Called by guess button
// Input: players guess  
// Return: status of guess
/**************************************************************/
const GUESSMAX = 101;
const GUESSMIN = 0;
function fbR_playerGuess() {
    console.log("fbR_playerGuess");
    var playerGuess = document.getElementById("playerGuess").value;
    var secretNumber = sessionStorage.getItem("secretNumber");
    console.log(playerGuess);
    
    if (isNaN(playerGuess)) {
        console.error("Guess not a number");
        alert("Please guess a number (e.g. '1', not 'one')");
    }
    else if (playerGuess >= GUESSMAX || playerGuess <= GUESSMIN) {
        console.error("invalid guess boundary");
        alert("Please guess a number between 1-100");
    }
    /**else if (Number.isInteger(playerGuess == false) {
        console.log("invalid guess not integer")
        alert("Please guess a whole number")
    }**/
    else {
        clearInterval(gameTimeout);
        document.getElementById("turn-timer").innerHTML = '';
        var lobbyID = sessionStorage.getItem("lobbyID");
        var playerStatus = sessionStorage.getItem("playerStatus");
        console.log(lobbyID + ' - ' + playerStatus);
        fb_writeRec('games/GTN/' + lobbyID + '/' + playerStatus, 
        'currentGuess', playerGuess, fbR_playerGuessCheck);
        if (playerGuess == secretNumber) {
            document.getElementById("guessStatus").innerHTML = 'Correct!';
            document.getElementById("mysteryNumberText").innerHTML = playerGuess;
           // userDetails.GTNwins ++;
           // console.log(userDetails.GTNwins)
           // fb_writeRec
           // ('scores/GTN', userDetails.gameName, userDetails.GTNwins, fbR_procWrite);
            fb_writeRec
            ('games/GTN/' + lobbyID, 'gameStatus', playerStatus + 'Win', fbR_procWrite);
        }
        else {
            if (playerGuess > secretNumber) {
                document.getElementById("hint").innerHTML = 'Too high';
            }
            else if (playerGuess < secretNumber) {
                document.getElementById("hint").innerHTML = 'Too low';
            }
            document.getElementById("guessStatus").innerHTML = 'Incorrect';
            //change turn
            document.getElementById("turn").innerHTML = 'Their turn...';
            if (playerStatus == 'p1') {
                fb_writeRec('games/GTN/' + lobbyID, 'turn', 2, fbR_procWrite);
            }
            else if (playerStatus == 'p2') {
                fb_writeRec('games/GTN/' + lobbyID, 'turn', 1, fbR_procWrite);
            }
        }
    }
}
/**************************************************************/
// fbR_playerGuessCheck 
// Reads the other players guess
// Called by readon
// Input:   snapshot
// Return: guess status
/**************************************************************/
function fbR_playerGuessCheck() {
    
}
/**************************************************************/
// fbR_procReadGuess (_readStatus, _snapshot, _save)
// Reads the other players guess
// Called by readon
// Input:   snapshot
// Return: guess status
/**************************************************************/
function fbR_procReadGuess(_readStatus, _snapshot, _save) {
    console.log("fbR_procReadGuess");
    var opponentGuess = _snapshot.val();
    var secretNumber = sessionStorage.getItem("secretNumber");
    console.log(secretNumber);
    document.getElementById("opponentGuessText").innerHTML = opponentGuess;
    if (opponentGuess == '...') {
       document.getElementById("hint-2").innerHTML = '';
    }
    else if (opponentGuess > secretNumber) {
        document.getElementById("hint-2").innerHTML = 'Too high';
    }
    else if (opponentGuess < secretNumber) {
        document.getElementById("hint-2").innerHTML = 'Too low';
    }
}
/**************************************************************/
// fbR_procNumber()
// Gets the secret number
// Called onload
// Input:   snapshot
// Return:  secretnumber
/**************************************************************/
function fbR_procNumber(_readStatus, _snapshot){
    console.log("fbR_procReadAllUD: readStatus= " + _readStatus);
    var dbData = _snapshot.val();
    console.log(dbData);
    sessionStorage.setItem("secretNumber", dbData);
}
/**************************************************************/
// fbR_procWins()
// Gets the wins of the player
// Called onload
// Input:   snapshot
// Return:  GTNwins
/**************************************************************/
function fbR_procWins(_readStatus, _snapshot){
    console.log("fbR_procWins: readStatus= " + _readStatus);
    var dbData = _snapshot.val();
    console.log("wins: " + dbData);
    if (dbData == null) {
        sessionStorage.setItem("GTNwins", 0);
    }
    else {
        sessionStorage.setItem("GTNwins", dbData);
    }
}
/**************************************************************/
// fbR_p1OnDisconnect()
// Ondisconnet for the lobby
// Called ondisconnect
// Input:   path, key
// Return: n/a
/**************************************************************/
function fbR_p1OnDisconnect (_path, _key) {
    console.log("fbR_p1OnDisconnect");
    var ref = firebase.database().ref(_path + '/' + _key);
    ref.onDisconnect().remove();
}
/**************************************************************/
// fbR_procReadTurn()
// Reads the turn status
// Called by onload
// Input:   snapshot
// Return: turn status
/**************************************************************/
function fbR_procReadTurn(_readStatus, _snapshot, _save) {
    var turnStatus = _snapshot.val();
    var playerStatus = sessionStorage.getItem("playerStatus");
    if (playerStatus == 'p1') {
        if (turnStatus == 1) {
            document.getElementById("guessButton").disabled = false;
            document.getElementById("turn").innerHTML = 'Your turn!';
            fbR_gameTimer();
            gameTimerVar = 30;
        }
        else  if (turnStatus == 2) {
           document.getElementById("guessButton").disabled = true;
        }
    }
    else if (playerStatus == 'p2') {
        if (turnStatus == 1) {
           document.getElementById("guessButton").disabled = true;
        }
        else  if (turnStatus == 2) {
           document.getElementById("guessButton").disabled = false;
           document.getElementById("turn").innerHTML = 'Your turn!';
           fbR_gameTimer();
           gameTimerVar = 30;
        }
    }
}
/**************************************************************/
// fbR_procReadWin()
// Determine when the game is won
// Called by readon
// Input:   snapshot
// Return: win message
/**************************************************************/
function fbR_procReadWin(_readStatus, _snapshot, _save) {
    var dbData = _snapshot.val();
    var playerStatus = sessionStorage.getItem("playerStatus");
    var winValue;
    if (playerStatus == 'p1') {
        winValue = 'p1Win';
        loseValue = 'p2Win';
    }
    else if (playerStatus == 'p2') {
        winValue = 'p2Win';
        loseValue = 'p1Win';
    }
    if (dbData == winValue) {
        document.getElementById('gameModal').style.display='block';      
        // player wins 
        document.getElementById("modalWinText").innerHTML = "You win";
        //fb_writeRec()
        userDetails.GTNwins ++;
        console.log(userDetails.GTNwins);
        fb_writeRec
        ('scores/GTN', userDetails.gameName, userDetails.GTNwins, fbR_procWrite);
    }
    else if (dbData == loseValue) {
        document.getElementById('gameModal').style.display='block';        
        //player loses
        document.getElementById("modalWinText").innerHTML = "You lose";
    }
}
/**************************************************************/
// fbR_gameEnd()
// Removes game record
// Called by back button
// Input:  n/a
// Return:  n/a
/**************************************************************/
function fbR_gameEnd () {
    console.log('fbR_gameEnd');
    var lobbyID = sessionStorage.getItem("lobbyID");
    window.location = '/lobby.html/';
    fb_remove('games/GTN', lobbyID);
}
/**************************************************************/
// fbR_gameTimer (_path, _key)
// Turn timer for the game
// Called by the Turn system
// Input: n/a
// Return:  win or lose 
/**************************************************************/
var gameTimerVar = 30;
var gameTimeout;
var playerStatus = sessionStorage.getItem("playerStatus");
var lobbyID = sessionStorage.getItem("lobbyID");
function fbR_gameTimer () {
    gameTimeout = setInterval(gameTimer, 1000);
    function gameTimer () {
        console.log("timer: " + gameTimerVar);
        gameTimerVar--;
        document.getElementById("turn-timer").innerHTML = 
        "time remaining: " + gameTimerVar;
        if (gameTimerVar == 0) {
            var otherPlayer = sessionStorage.getItem("otherPlayer");
            fb_writeRec
            ('games/GTN/' + lobbyID, 'gameStatus', otherPlayer + 'Win', fbR_procWrite);
            //fb_writeRec
            //('userDetails/' + userDetails.uid, 'wins', 13, fbR_procWrite);
            clearInterval(gameTimeout);
        }
    }
} 
/**************************************************************/
// kaUnderConstruction()
// Alert that the game is under construction
// Input: n/a
// Return: n/a
/**************************************************************/
function kaUnderConstruction() {
    alert("Game is under construction");
}
/**************************************************************/
//    END OF MODULE
/**************************************************************/