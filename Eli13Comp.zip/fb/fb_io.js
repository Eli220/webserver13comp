/**************************************************************/
// fb_io.js

// Written by Eli Church

// All generic functions for the firebase
/**************************************************************/
MODULENAME = "fb_io.js";
console.log('%c' + MODULENAME + ': ', 'color: blue;');
/**************************************************************/
// fb_login(_save, _procfunc)
// Called by setup
// Login to Firebase
// Input: Passing name of the function to process login data 
// Return: n/a
/**************************************************************/
function fb_login(_save, _procfunc) {
  console.log('%cfb_login: ', 'color: brown;');
  
  firebase.auth().onAuthStateChanged(newLogin);

  /*-----------------------------------------*/
  // newLogin(user)
  /*-----------------------------------------*/
  function newLogin(user) {
    console.log(user);
    if (user) {
      // user is signed in, so save Google login details
      loginStatus    = 'logged in';
      _procfunc(loginStatus, user, _save);
    } 
    else {
      // user NOT logged in, so redirect to Google login
      loginStatus = 'logged out';
      
      var provider = new firebase.auth.GoogleAuthProvider();
      firebase.auth().signInWithPopup(provider).then(function(result) {
        loginStatus    = 'logged in via popup';
        _procfunc(loginStatus, result.user, _save);
      })
      // Catch errors
      .catch(function(error) {
        if (error) {
          loginStatus = 'failed';
          console.log('%cfb_login: ' + error.code + ', ' +
            error.message, 'color: red;');
        }
      });
    }
    console.log('fb_login: status = ' + loginStatus);
  }
}
/**************************************************************/
// fb_logout()
// Logout of Firebase
// Input:  n/a
// Return: n/a
/**************************************************************/
function fb_logout() {
  console.log('%cfb_logout: ', 'color: brown;');
  firebase.auth().signOut();
}
/**************************************************************/
// fb_writeRec(_path, _key, _data, procfunc)
// Write a specific record & key to the DB
// Input:  path to write to, the key and the data to write
// Return: Error or successful write
/**************************************************************/
function fb_writeRec(_path, _key, _data, _procfunc) { 
  console.log('%cfb_WriteRec: path= ' + _path + '  key= ' + _key +
              '  data= ' + _data.name + '/' + _data.score, 
              'color: brown;');
  
  writeStatus = "waiting...";
  firebase.database().ref(_path + '/' + _key).set(_data,
    function(error) {
      _procfunc(error);
    });
  console.log("fb_writeRec end");
}
/**************************************************************/
// fb_readAll(_path, _procFunc) 
// Read all DB records for the path
// Input:  path to read from & function to process firebase data
// Return:
// _path, _snapshot, _save, _result, _error
/**************************************************************/
function fb_readAll(_path, _procFunc) {
  console.log('%cfb_readAll: path= ' + _path, 'color: brown;');

    _path.toString();
  readStatus = "waiting";
  firebase.database().ref(_path).once("value", gotRecord, readErr);

  function gotRecord (snapshot){
          console.log(snapshot);

    _procFunc (_path, snapshot, null, 'OK');
       // _procFunc (snapshot, _path, null);
  }

  function readErr (_error){
    _procFunc (_path, null, _error);
  }
}
/**************************************************************/
// fb_readRec(_path, _key, _save, _processData)
// Read a specific DB record
// Input:  path & key of record to read and where to save the data
// Return:  successful read/no record/failed read
/**************************************************************/
function fb_readRec(_path, _key, _processData, _save) {	
  console.log('%cfb_readRec: path= ' + _path + 
              '  key= ' + _key, 'color: brown;');

  var readStatus = "waiting";
  firebase.database().ref(_path + '/' + _key).once("value", gotRecord, readErr);
  if (_save == null){
      _save = 'saveNull';
  }
  function gotRecord(snapshot) {
    console.log("gotRecord");
    console.log(_processData);
    console.log(snapshot);
    _processData(readStatus, snapshot, _save);
  }
  function readErr(_error) {
    console.log("readErr");
    readStatus = "failed";
    _processData(readStatus, null, null, error);
  }
}
/**************************************************************/
// fb_readAllSorted(_path, _save, _sortKey, _num, _procFunc)
// Called by various
// Read all records for path & return top _num sorted records
// Input:  path to read from & array of object to save data in,
//          sort key & number of records to return
//          and function to process the data.
// Return: The array in sorted order
/**************************************************************/
function fb_readAllSorted(_path, _save, _sortKey, _num, _procFunc) {
  console.log('%cfb_readAllSorted: path= ' + _path, 'color: brown');

  readStatus = "waiting";
  database.ref(_path).orderByValue().limitToLast(_num)
                     .once('value', gotRecord, readErr);

  function gotRecord (snapshot){
    console.log(snapshot);
    _procFunc (_path, snapshot, _save);
  }

  function readErr (_error){
    _procFunc (_path, null, _error);
  }
}
/**************************************************************/
// fb_readOn(_path, _key, _save, _processData)
// Listen to a DB record
// Input:  path & key of record to listen
// Return:  successful read/no record/failed read
/**************************************************************/
function fb_readOn(_path, _key, _processData, _save) {	
  console.log('%cfb_readOn: path= ' + _path + 
              '  key= ' + _key, 'color: brown;');

  var readStatus = "waiting";
  firebase.database().ref(_path + '/' + _key).on("value", gotRecord, readErr);
  
  function gotRecord(snapshot) {
    console.log("gotRecord");
    console.log(snapshot);
    _processData(readStatus, snapshot, _save);
  }
  function readErr(_error) {
    console.log("readErr");
    readStatus = "failed";
    _processData(readStatus, null, null, error);
  }
}
/**************************************************************/
// fb_readOnCancel(_path, _key, _save, _processData)
// Listen to a DB record
// Input:  path & key of record to listen
// Return:  successful read/no record/failed read
/**************************************************************/
function fb_readOnCancel(_path, _key, _processData, _save) {	
  console.log('%cfb_readOnCancel: path= ' + _path + 
              '  key= ' + _key, 'color: brown;');
              
  firebase.database().ref(_path + '/' + _key).off();
  var readStatus = "waiting";
  console.log("readOnCancelled: " + _path);
  
}
/**************************************************************/
// fb_remove(_path, _key)
// Listen to a DB record
// Input:  path & key of record to listen
// Return:  successful read/no record/failed read
/**************************************************************/
function fb_remove(_path, _key) {
    console.log("fb_remove: " + _path + '/' + _key);
    firebase.database().ref(_path + '/' + _key).remove();
}
/**************************************************************/
//    END OF MODULE
/**************************************************************/